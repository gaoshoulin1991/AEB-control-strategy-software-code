
set MATLAB=C:\gaosl\program\matlab

cd .

if "%1"=="" ("C:\gaosl\program\matlab\bin\win64\gmake"  -f PSO_LQR.mk all) else ("C:\gaosl\program\matlab\bin\win64\gmake"  -f PSO_LQR.mk %1)
@if errorlevel 1 goto error_exit

exit /B 0

:error_exit
echo The make command returned an error of %errorlevel%
exit /B 1