/*
 * PSO_LQR.h
 *
 * Code generation for model "PSO_LQR".
 *
 * Model version              : 2.0
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C source code generated on : Tue Jul  7 19:32:14 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PSO_LQR_h_
#define RTW_HEADER_PSO_LQR_h_
#ifndef PSO_LQR_COMMON_INCLUDES_
#define PSO_LQR_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* PSO_LQR_COMMON_INCLUDES_ */

#include "PSO_LQR_types.h"
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T FromWorkspace[2015];          /* '<Root>/From Workspace' */
  real_T FromWorkspace1[2015];         /* '<Root>/From Workspace1' */
  real_T FromWorkspace2[2015];         /* '<Root>/From Workspace2' */
  real_T FromWorkspace3[2015];         /* '<Root>/From Workspace3' */
  real_T err[4];                       /* '<Root>/err_kappa_calculate_module' */
} B_PSO_LQR_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace4_PWORK;              /* '<Root>/From Workspace4' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace5_PWORK;              /* '<Root>/From Workspace5' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace6_PWORK;              /* '<Root>/From Workspace6' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace7_PWORK;              /* '<Root>/From Workspace7' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace_PWORK;               /* '<Root>/From Workspace' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace1_PWORK;              /* '<Root>/From Workspace1' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace2_PWORK;              /* '<Root>/From Workspace2' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace3_PWORK;              /* '<Root>/From Workspace3' */

  struct {
    int_T PrevIndex;
  } FromWorkspace4_IWORK;              /* '<Root>/From Workspace4' */

  struct {
    int_T PrevIndex;
  } FromWorkspace5_IWORK;              /* '<Root>/From Workspace5' */

  struct {
    int_T PrevIndex;
  } FromWorkspace6_IWORK;              /* '<Root>/From Workspace6' */

  struct {
    int_T PrevIndex;
  } FromWorkspace7_IWORK;              /* '<Root>/From Workspace7' */

  struct {
    int_T PrevIndex;
  } FromWorkspace_IWORK;               /* '<Root>/From Workspace' */

  struct {
    int_T PrevIndex;
  } FromWorkspace1_IWORK;              /* '<Root>/From Workspace1' */

  struct {
    int_T PrevIndex;
  } FromWorkspace2_IWORK;              /* '<Root>/From Workspace2' */

  struct {
    int_T PrevIndex;
  } FromWorkspace3_IWORK;              /* '<Root>/From Workspace3' */
} DW_PSO_LQR_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T x;                            /* '<Root>/x' */
  real_T y;                            /* '<Root>/y' */
  real_T phi;                          /* '<Root>/phi' */
  real_T vx;                           /* '<Root>/vx' */
  real_T vy;                           /* '<Root>/vy' */
  real_T phi_dot;                      /* '<Root>/phi_dot' */
} ExtU_PSO_LQR_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T angle;                        /* '<Root>/angle' */
} ExtY_PSO_LQR_T;

/* Parameters (default storage) */
struct P_PSO_LQR_T_ {
  real_T Gain3_Gain;                   /* Expression: pi/180
                                        * Referenced by: '<Root>/Gain3'
                                        */
  real_T Gain_Gain;                    /* Expression: 1/3.6
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1/3.6
                                        * Referenced by: '<Root>/Gain1'
                                        */
  real_T Gain2_Gain;                   /* Expression: pi/180
                                        * Referenced by: '<Root>/Gain2'
                                        */
  real_T Constant_Value;               /* Expression: 0.1
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1.015
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 2.91-1.015
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 1412
                                        * Referenced by: '<Root>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: -110000
                                        * Referenced by: '<Root>/Constant4'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_PSO_LQR_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    struct {
      uint8_T TID[3];
    } TaskCounters;

    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[3];
  } Timing;
};

/* Block parameters (default storage) */
extern P_PSO_LQR_T PSO_LQR_P;

/* Block signals (default storage) */
extern B_PSO_LQR_T PSO_LQR_B;

/* Block states (default storage) */
extern DW_PSO_LQR_T PSO_LQR_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_PSO_LQR_T PSO_LQR_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_PSO_LQR_T PSO_LQR_Y;

/* Model entry point functions */
extern void PSO_LQR_initialize(void);
extern void PSO_LQR_step(void);
extern void PSO_LQR_terminate(void);

/* Real-time Model object */
extern RT_MODEL_PSO_LQR_T *const PSO_LQR_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PSO_LQR'
 * '<S1>'   : 'PSO_LQR/err_kappa_calculate_module'
 * '<S2>'   : 'PSO_LQR/forword_control'
 * '<S3>'   : 'PSO_LQR/last_angle'
 * '<S4>'   : 'PSO_LQR/lqr_offline'
 * '<S5>'   : 'PSO_LQR/predict_module'
 */
#endif                                 /* RTW_HEADER_PSO_LQR_h_ */
