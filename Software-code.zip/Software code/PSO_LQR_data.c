/*
 * PSO_LQR_data.c
 *
 * Code generation for model "PSO_LQR".
 *
 * Model version              : 2.0
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C source code generated on : Tue Jul  7 19:32:14 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PSO_LQR.h"

/* Block parameters (default storage) */
P_PSO_LQR_T PSO_LQR_P = {
  /* Expression: pi/180
   * Referenced by: '<Root>/Gain3'
   */
  0.017453292519943295,

  /* Expression: 1/3.6
   * Referenced by: '<Root>/Gain'
   */
  0.27777777777777779,

  /* Expression: 1/3.6
   * Referenced by: '<Root>/Gain1'
   */
  0.27777777777777779,

  /* Expression: pi/180
   * Referenced by: '<Root>/Gain2'
   */
  0.017453292519943295,

  /* Expression: 0.1
   * Referenced by: '<Root>/Constant'
   */
  0.1,

  /* Expression: 1.015
   * Referenced by: '<Root>/Constant1'
   */
  1.015,

  /* Expression: 2.91-1.015
   * Referenced by: '<Root>/Constant2'
   */
  1.8950000000000002,

  /* Expression: 1412
   * Referenced by: '<Root>/Constant3'
   */
  1412.0,

  /* Expression: -110000
   * Referenced by: '<Root>/Constant4'
   */
  -110000.0
};
