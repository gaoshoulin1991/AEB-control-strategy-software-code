/*
 * PSO_LQR_types.h
 *
 * Code generation for model "PSO_LQR".
 *
 * Model version              : 2.0
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C source code generated on : Tue Jul  7 19:32:14 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PSO_LQR_types_h_
#define RTW_HEADER_PSO_LQR_types_h_

/* Parameters (default storage) */
typedef struct P_PSO_LQR_T_ P_PSO_LQR_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_PSO_LQR_T RT_MODEL_PSO_LQR_T;

#endif                                 /* RTW_HEADER_PSO_LQR_types_h_ */
